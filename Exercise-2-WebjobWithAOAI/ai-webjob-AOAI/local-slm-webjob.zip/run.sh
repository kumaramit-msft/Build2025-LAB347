#!/bin/bash

echo "Starting AI webjob"
export USE_LOCAL_SLM=true
dotnet ai-webjob.dll
echo "AI webjob finshed"
