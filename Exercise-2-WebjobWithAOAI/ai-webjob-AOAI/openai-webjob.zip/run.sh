#!/bin/bash

echo "Starting AI webjob"
dotnet ai-webjob.dll
echo "AI webjob finshed"
